-- 说明：仅用于本地开发演示。请在执行前替换为你自定义强密码的 BCrypt 哈希。
-- 示例（请替换）：UPDATE user SET password = '<REPLACE_WITH_YOUR_BCRYPT_HASH>' WHERE username = 'admin';
UPDATE `user` SET `password` = '$2b$12$nWSsGK8tQtyxGXRyMNemt.6Ky/MYOZu0jIZCcRGfMtFg8QvT5Cr6a' WHERE `username` = 'admin';
