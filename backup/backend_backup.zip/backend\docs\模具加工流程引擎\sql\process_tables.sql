-- 模具加工流程引擎 - 数据库表结构设计
-- 创建时间：2024年
-- 数据库：MySQL 8.0+
-- 字符集：utf8mb4

-- =============================================
-- 模具加工流程主表
-- =============================================
CREATE TABLE IF NOT EXISTS mold_process (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    process_code VARCHAR(50) NOT NULL COMMENT '流程编号',
    process_name VARCHAR(100) NOT NULL COMMENT '流程名称',
    mold_id BIGINT NOT NULL COMMENT '模具ID',
    equipment_id BIGINT NOT NULL COMMENT '设备ID',
    operator_id BIGINT NOT NULL COMMENT '操作员ID',
    
    -- 流程状态信息
    current_status VARCHAR(50) NOT NULL DEFAULT 'PENDING' COMMENT '当前状态',
    previous_status VARCHAR(50) COMMENT '上一个状态',
    
    -- 计划信息
    planned_start_time DATETIME COMMENT '计划开始时间',
    planned_end_time DATETIME COMMENT '计划结束时间',
    planned_quantity INT NOT NULL DEFAULT 0 COMMENT '计划生产数量',
    
    -- 实际执行信息
    actual_start_time DATETIME COMMENT '实际开始时间',
    actual_end_time DATETIME COMMENT '实际结束时间',
    actual_quantity INT NOT NULL DEFAULT 0 COMMENT '实际生产数量',
    qualified_quantity INT NOT NULL DEFAULT 0 COMMENT '合格数量',
    defective_quantity INT NOT NULL DEFAULT 0 COMMENT '不良数量',
    
    -- 进度跟踪
    progress_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00 COMMENT '进度百分比',
    estimated_remaining_time INT COMMENT '预计剩余时间（分钟）',
    
    -- 质量信息
    quality_score DECIMAL(5,2) COMMENT '质量评分',
    inspection_result VARCHAR(20) COMMENT '检验结果：PASS/FAIL/PENDING',
    inspection_remark VARCHAR(500) COMMENT '检验备注',
    
    -- 异常信息
    has_exception TINYINT NOT NULL DEFAULT 0 COMMENT '是否有异常：0-无，1-有',
    exception_count INT NOT NULL DEFAULT 0 COMMENT '异常次数',
    
    -- 系统字段
    description VARCHAR(500) COMMENT '流程描述',
    remark VARCHAR(500) COMMENT '备注',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    create_by BIGINT COMMENT '创建人',
    update_by BIGINT COMMENT '更新人',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
    
    -- 唯一约束
    CONSTRAINT uk_process_code UNIQUE (process_code),
    
    -- 外键约束
    FOREIGN KEY (mold_id) REFERENCES mold (id) ON DELETE RESTRICT,
    FOREIGN KEY (equipment_id) REFERENCES equipment (id) ON DELETE RESTRICT,
    FOREIGN KEY (operator_id) REFERENCES `user` (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模具加工流程主表';

-- =============================================
-- 流程状态历史记录表
-- =============================================
CREATE TABLE IF NOT EXISTS process_status_history (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    process_id BIGINT NOT NULL COMMENT '流程ID',
    from_status VARCHAR(50) NOT NULL COMMENT '原状态',
    to_status VARCHAR(50) NOT NULL COMMENT '目标状态',
    
    -- 状态变更信息
    change_reason VARCHAR(200) COMMENT '变更原因',
    change_remark VARCHAR(500) COMMENT '变更备注',
    operator_id BIGINT NOT NULL COMMENT '操作员ID',
    
    -- 系统字段
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    
    -- 外键约束
    FOREIGN KEY (process_id) REFERENCES mold_process (id) ON DELETE CASCADE,
    FOREIGN KEY (operator_id) REFERENCES `user` (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='流程状态历史记录表';

-- =============================================
-- 加工异常记录表
-- =============================================
CREATE TABLE IF NOT EXISTS process_exception (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    process_id BIGINT NOT NULL COMMENT '流程ID',
    
    -- 异常信息
    exception_type VARCHAR(50) NOT NULL COMMENT '异常类型',
    exception_level VARCHAR(20) NOT NULL DEFAULT 'MEDIUM' COMMENT '异常级别：LOW/MEDIUM/HIGH/CRITICAL',
    exception_description TEXT NOT NULL COMMENT '异常描述',
    
    -- 处理信息
    handler_id BIGINT COMMENT '处理人ID',
    handling_method VARCHAR(100) COMMENT '处理方法',
    handling_result VARCHAR(20) COMMENT '处理结果：PENDING/RESOLVED/ESCALATED',
    handling_remark VARCHAR(500) COMMENT '处理备注',
    
    -- 时间信息
    exception_time DATETIME NOT NULL COMMENT '异常发生时间',
    handling_start_time DATETIME COMMENT '处理开始时间',
    handling_end_time DATETIME COMMENT '处理结束时间',
    handling_duration INT COMMENT '处理时长（分钟）',
    
    -- 系统字段
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    create_by BIGINT COMMENT '创建人',
    update_by BIGINT COMMENT '更新人',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
    
    -- 外键约束
    FOREIGN KEY (process_id) REFERENCES mold_process (id) ON DELETE CASCADE,
    FOREIGN KEY (handler_id) REFERENCES `user` (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='加工异常记录表';

-- =============================================
-- 质量检验结果表
-- =============================================
CREATE TABLE IF NOT EXISTS inspection_result (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT '主键ID',
    process_id BIGINT NOT NULL COMMENT '流程ID',
    
    -- 检验信息
    inspector_id BIGINT NOT NULL COMMENT '检验员ID',
    inspection_time DATETIME NOT NULL COMMENT '检验时间',
    inspection_result VARCHAR(20) NOT NULL COMMENT '检验结果：PASS/FAIL',
    
    -- 检验详情
    quality_score DECIMAL(5,2) NOT NULL COMMENT '质量评分',
    defect_count INT NOT NULL DEFAULT 0 COMMENT '缺陷数量',
    major_defect_count INT NOT NULL DEFAULT 0 COMMENT '主要缺陷数量',
    minor_defect_count INT NOT NULL DEFAULT 0 COMMENT '次要缺陷数量',
    
    -- 检验标准
    inspection_standard VARCHAR(100) COMMENT '检验标准',
    inspection_method VARCHAR(100) COMMENT '检验方法',
    
    -- 详细结果
    inspection_details TEXT COMMENT '检验详情',
    improvement_suggestions TEXT COMMENT '改进建议',
    
    -- 系统字段
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    create_by BIGINT COMMENT '创建人',
    update_by BIGINT COMMENT '更新人',
    deleted TINYINT NOT NULL DEFAULT 0 COMMENT '逻辑删除：0-未删除，1-已删除',
    
    -- 外键约束
    FOREIGN KEY (process_id) REFERENCES mold_process (id) ON DELETE CASCADE,
    FOREIGN KEY (inspector_id) REFERENCES `user` (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='质量检验结果表';

-- =============================================
-- 创建索引优化查询性能
-- =============================================

-- 模具加工流程表索引
CREATE INDEX idx_mold_process_status ON mold_process(current_status);
CREATE INDEX idx_mold_process_mold ON mold_process(mold_id);
CREATE INDEX idx_mold_process_equipment ON mold_process(equipment_id);
CREATE INDEX idx_mold_process_operator ON mold_process(operator_id);
CREATE INDEX idx_mold_process_planned_time ON mold_process(planned_start_time, planned_end_time);
CREATE INDEX idx_mold_process_actual_time ON mold_process(actual_start_time, actual_end_time);
CREATE INDEX idx_mold_process_progress ON mold_process(progress_percentage);
CREATE INDEX idx_mold_process_exception ON mold_process(has_exception);

-- 流程状态历史表索引
CREATE INDEX idx_status_history_process ON process_status_history(process_id);
CREATE INDEX idx_status_history_time ON process_status_history(create_time);
CREATE INDEX idx_status_history_status ON process_status_history(from_status, to_status);

-- 加工异常记录表索引
CREATE INDEX idx_exception_process ON process_exception(process_id);
CREATE INDEX idx_exception_type ON process_exception(exception_type);
CREATE INDEX idx_exception_level ON process_exception(exception_level);
CREATE INDEX idx_exception_time ON process_exception(exception_time);
CREATE INDEX idx_exception_result ON process_exception(handling_result);

-- 质量检验结果表索引
CREATE INDEX idx_inspection_process ON inspection_result(process_id);
CREATE INDEX idx_inspection_time ON inspection_result(inspection_time);
CREATE INDEX idx_inspection_result ON inspection_result(inspection_result);
CREATE INDEX idx_inspection_score ON inspection_result(quality_score);

-- =============================================
-- 表结构说明
-- =============================================

-- mold_process 表：
-- 1. 记录模具加工流程的核心信息
-- 2. 支持状态机流转（current_status, previous_status）
-- 3. 包含计划和实际执行的时间、数量信息
-- 4. 支持进度跟踪和质量控制

-- process_status_history 表：
-- 1. 记录流程状态变更的历史轨迹
-- 2. 支持状态变更原因和操作员追踪
-- 3. 为状态机提供完整的审计日志

-- process_exception 表：
-- 1. 记录加工过程中的异常情况
-- 2. 支持异常分类和级别管理
-- 3. 记录异常处理过程和结果

-- inspection_result 表：
-- 1. 记录质量检验的详细结果
-- 2. 支持缺陷分类和评分机制
-- 3. 提供质量改进建议

-- =============================================
-- 状态机状态定义
-- =============================================

-- 模具加工流程状态定义：
-- PENDING: 待开始
-- PREPARING: 准备中
-- PROCESSING: 加工中
-- PAUSED: 已暂停
-- QUALITY_CHECK: 质量检验
-- COMPLETED: 已完成
-- CANCELLED: 已取消
-- EXCEPTION: 异常状态

-- =============================================
-- 异常类型定义
-- =============================================

-- 常见异常类型：
-- EQUIPMENT_FAILURE: 设备故障
-- MATERIAL_DEFECT: 材料缺陷
-- OPERATOR_ERROR: 操作错误
-- QUALITY_ISSUE: 质量问题
-- PROCESS_DELAY: 流程延迟
-- SAFETY_INCIDENT: 安全事故

-- =============================================
-- 创建完成确认
-- =============================================
SELECT '模具加工流程引擎表结构创建完成！' AS message;