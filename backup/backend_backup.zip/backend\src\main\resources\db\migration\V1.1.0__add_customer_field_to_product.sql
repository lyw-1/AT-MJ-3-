-- 向成品表添加客户字段
ALTER TABLE `product` 
ADD COLUMN `customer` VARCHAR(255) NULL COMMENT '客户名称' AFTER `other_requirements`;

-- 更新现有数据的客户字段，设置默认值
UPDATE `product` SET `customer` = '默认客户' WHERE `customer` IS NULL;