-- 操作日志表索引优化脚本
-- 创建时间：2024-01-20

-- 为operation_log表添加额外的优化索引

-- 1. 添加is_sensitive字段的索引，用于敏感操作查询
CREATE INDEX idx_is_sensitive ON operation_log(is_sensitive);

-- 2. 添加sensitive_level字段的索引，用于敏感级别过滤
CREATE INDEX idx_sensitive_level ON operation_log(sensitive_level);

-- 3. 添加user_id字段的索引，用于用户ID查询
CREATE INDEX idx_user_id ON operation_log(user_id);

-- 4. 添加模块字段的索引，用于按模块统计
CREATE INDEX idx_module ON operation_log(module);

-- 5. 添加结果字段的索引，用于按结果过滤
CREATE INDEX idx_result ON operation_log(result);

-- 6. 创建复合索引，优化时间范围和敏感操作的联合查询
CREATE INDEX idx_create_time_is_sensitive ON operation_log(create_time, is_sensitive);

-- 7. 创建复合索引，优化时间范围和操作类型的联合查询
CREATE INDEX idx_create_time_operation_type ON operation_log(create_time, operation_type);

-- 8. 创建复合索引，优化用户和时间范围的联合查询
CREATE INDEX idx_username_create_time ON operation_log(username, create_time);

-- 验证索引创建结果
SHOW INDEX FROM operation_log;