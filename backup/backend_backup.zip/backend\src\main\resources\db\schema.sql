-- 模具数字化管理系统 - 数据库表结构SQL脚本

-- 创建用户表
CREATE TABLE `USER` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `real_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `status` tinyint DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`username`)
);

-- 创建角色表
CREATE TABLE `ROLE` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) NOT NULL,
  `role_code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`role_code`)
);

-- 创建用户角色关联表
CREATE TABLE `USER_ROLE` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`user_id`,`role_id`),
  INDEX `fk_user_role_role` (`role_id`),
  CONSTRAINT `fk_user_role_role` FOREIGN KEY (`role_id`) REFERENCES `ROLE` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_role_user` FOREIGN KEY (`user_id`) REFERENCES `USER` (`id`) ON DELETE CASCADE
);

-- 创建模具类型表
CREATE TABLE `MOLD_TYPE` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type_name` varchar(100) NOT NULL,
  `type_code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`type_code`)
);

-- 创建模具状态表
CREATE TABLE `MOLD_STATUS` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `status_name` varchar(100) NOT NULL,
  `status_code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`status_code`)
);

-- 创建模具表
CREATE TABLE `MOLD` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mold_code` varchar(50) NOT NULL,
  `mold_name` varchar(100) NOT NULL,
  `mold_type_id` bigint NOT NULL,
  `mold_status_id` bigint NOT NULL,
  `specification` varchar(255) DEFAULT NULL,
  `material` varchar(100) DEFAULT NULL,
  `life_cycle` int DEFAULT 0,
  `current_count` int DEFAULT 0,
  `manufacture_date` date DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`mold_code`),
  INDEX `fk_mold_type` (`mold_type_id`),
  INDEX `fk_mold_status` (`mold_status_id`),
  CONSTRAINT `fk_mold_status` FOREIGN KEY (`mold_status_id`) REFERENCES `MOLD_STATUS` (`id`),
  CONSTRAINT `fk_mold_type` FOREIGN KEY (`mold_type_id`) REFERENCES `MOLD_TYPE` (`id`)
);

-- 创建设备类型表
CREATE TABLE `EQUIPMENT_TYPE` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type_name` varchar(100) NOT NULL,
  `type_code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`type_code`)
);

-- 创建设备表
CREATE TABLE `EQUIPMENT` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `equipment_code` varchar(50) NOT NULL,
  `equipment_name` varchar(100) NOT NULL,
  `equipment_type_id` bigint NOT NULL,
  `status` varchar(20) DEFAULT '正常',
  `location` varchar(100) DEFAULT NULL,
  `manufacture_date` date DEFAULT NULL,
  `manufacturer` varchar(100) DEFAULT NULL,
  `last_maintain_date` date DEFAULT NULL,
  `next_maintain_date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`equipment_code`),
  INDEX `fk_equipment_type` (`equipment_type_id`),
  CONSTRAINT `fk_equipment_type` FOREIGN KEY (`equipment_type_id`) REFERENCES `EQUIPMENT_TYPE` (`id`)
);

-- 创建生产任务表
CREATE TABLE `PRODUCTION_TASK` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_code` varchar(50) NOT NULL,
  `task_name` varchar(100) NOT NULL,
  `mold_id` bigint NOT NULL,
  `equipment_id` bigint NOT NULL,
  `operator_id` bigint DEFAULT NULL,
  `planned_quantity` int NOT NULL,
  `actual_quantity` int DEFAULT 0,
  `qualified_quantity` int DEFAULT 0,
  `defective_quantity` int DEFAULT 0,
  `status` varchar(20) DEFAULT '待开始',
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`task_code`),
  INDEX `fk_task_mold` (`mold_id`),
  INDEX `fk_task_equipment` (`equipment_id`),
  INDEX `fk_task_operator` (`operator_id`),
  CONSTRAINT `fk_task_equipment` FOREIGN KEY (`equipment_id`) REFERENCES `EQUIPMENT` (`id`),
  CONSTRAINT `fk_task_mold` FOREIGN KEY (`mold_id`) REFERENCES `MOLD` (`id`),
  CONSTRAINT `fk_task_operator` FOREIGN KEY (`operator_id`) REFERENCES `USER` (`id`)
);

-- 创建生产记录表
CREATE TABLE `PRODUCTION_RECORD` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` bigint NOT NULL,
  `mold_id` bigint NOT NULL,
  `equipment_id` bigint NOT NULL,
  `operator_id` bigint DEFAULT NULL,
  `production_date` datetime NOT NULL,
  `production_quantity` int NOT NULL,
  `qualified_quantity` int DEFAULT 0,
  `defective_quantity` int DEFAULT 0,
  `mold_usage_count` int DEFAULT 0,
  `equipment_parameters` text,
  `remark` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `fk_record_task` (`task_id`),
  INDEX `fk_record_mold` (`mold_id`),
  INDEX `fk_record_equipment` (`equipment_id`),
  INDEX `fk_record_operator` (`operator_id`),
  CONSTRAINT `fk_record_equipment` FOREIGN KEY (`equipment_id`) REFERENCES `EQUIPMENT` (`id`),
  CONSTRAINT `fk_record_mold` FOREIGN KEY (`mold_id`) REFERENCES `MOLD` (`id`),
  CONSTRAINT `fk_record_operator` FOREIGN KEY (`operator_id`) REFERENCES `USER` (`id`),
  CONSTRAINT `fk_record_task` FOREIGN KEY (`task_id`) REFERENCES `PRODUCTION_TASK` (`id`)
);

-- 创建系统参数表
CREATE TABLE `SYSTEM_PARAMETER` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `param_key` varchar(100) NOT NULL,
  `param_value` text,
  `param_type` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_visible` tinyint DEFAULT 1,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE (`param_key`)
);

-- 创建日志表
CREATE TABLE `LOG` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `operation_type` varchar(50) NOT NULL,
  `operation_content` varchar(255) NOT NULL,
  `operation_ip` varchar(50) DEFAULT NULL,
  `operation_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `success_flag` tinyint DEFAULT 1,
  `error_message` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_log_user` (`user_id`),
  CONSTRAINT `fk_log_user` FOREIGN KEY (`user_id`) REFERENCES `USER` (`id`)
);