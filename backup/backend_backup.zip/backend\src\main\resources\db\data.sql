-- 模具数字化管理系统 - 初始测试数据SQL脚本

-- 插入角色数据
INSERT INTO `role` (`role_name`, `role_code`, `description`) VALUES
('系统管理员', 'ADMIN', '系统最高权限管理员'),
('生产主管', 'PRODUCTION_MANAGER', '生产部门负责人'),
('设备管理员', 'EQUIPMENT_MANAGER', '设备管理负责人'),
('模具管理员', 'MOLD_MANAGER', '模具管理负责人'),
('普通用户', 'NORMAL_USER', '普通操作人员');

-- 插入用户数据（密码默认为123456，使用BCrypt加密）
INSERT INTO `user` (`username`, `password`, `real_name`, `phone`, `email`, `department`, `position`, `status`) VALUES
('admin', '$2a$10$i.C2YBL0E0Ru9tMvmnJ/NOjpvVdexEinnXb0kwJKc99Ow11FnaKTW', '系统管理员', '13800138000', 'admin@example.com', '信息技术部', '系统管理员', 1),
('zhangsan', '$2a$10$i.C2YBL0E0Ru9tMvmnJ/NOjpvVdexEinnXb0kwJKc99Ow11FnaKTW', '张三', '13800138001', 'zhangsan@example.com', '生产部', '生产主管', 1),
('lisi', '$2a$10$i.C2YBL0E0Ru9tMvmnJ/NOjpvVdexEinnXb0kwJKc99Ow11FnaKTW', '李四', '13800138002', 'lisi@example.com', '设备部', '设备管理员', 1),
('wangwu', '$2a$10$i.C2YBL0E0Ru9tMvmnJ/NOjpvVdexEinnXb0kwJKc99Ow11FnaKTW', '王五', '13800138003', 'wangwu@example.com', '模具部', '模具管理员', 1),
('zhaoliu', '$2a$10$i.C2YBL0E0Ru9tMvmnJ/NOjpvVdexEinnXb0kwJKc99Ow11FnaKTW', '赵六', '13800138004', 'zhaoliu@example.com', '生产部', '操作员', 1);

-- 插入用户角色关联数据
INSERT INTO `user_role` (`user_id`, `role_id`) VALUES
(1, 1),  -- admin拥有管理员角色
(2, 2),  -- zhangsan拥有生产主管角色
(3, 3),  -- lisi拥有设备管理员角色
(4, 4),  -- wangwu拥有模具管理员角色
(5, 5);  -- zhaoliu拥有普通用户角色

-- 插入模具类型数据
INSERT INTO `mold_type` (`type_name`, `type_code`, `description`) VALUES
('注塑模具', 'INJECTION_MOLD', '用于注塑成型的模具'),
('冲压模具', 'STAMPING_MOLD', '用于金属冲压的模具'),
('压铸模具', 'DIE_CASTING_MOLD', '用于金属压铸的模具'),
('锻造模具', 'FORGING_MOLD', '用于金属锻造的模具'),
('吹塑模具', 'BLOW_MOLDING_MOLD', '用于塑料吹塑的模具');

-- 插入模具状态数据
INSERT INTO `mold_status` (`status_name`, `status_code`, `description`) VALUES
('在用', 'IN_USE', '正在生产中使用的模具'),
('待修', 'TO_BE_REPAIRED', '需要维修的模具'),
('维修中', 'IN_REPAIR', '正在维修过程中的模具'),
('备用', 'STANDBY', '备用状态的模具'),
('报废', 'SCRAPPED', '已报废的模具');

-- 插入设备类型数据
INSERT INTO `equipment_type` (`type_name`, `type_code`, `description`) VALUES
('注塑机', 'INJECTION_MACHINE', '用于塑料注塑成型的设备'),
('冲压机', 'PRESS_MACHINE', '用于金属冲压的设备'),
('压铸机', 'DIE_CASTING_MACHINE', '用于金属压铸的设备'),
('数控铣床', 'CNC_MILLING', '用于模具加工的数控机床'),
('电火花机床', 'EDM_MACHINE', '用于模具精密加工的电火花设备');

-- 插入设备数据
INSERT INTO `equipment` (`equipment_code`, `equipment_name`, `equipment_type_id`, `status`, `location`, `manufacture_date`, `manufacturer`, `last_maintain_date`, `next_maintain_date`, `description`) VALUES
('EQ001', '注塑机1号', 1, '正常', '生产车间A区', '2020-01-15', '海天注塑机', '2023-12-01', '2024-03-01', '1200吨注塑机'),
('EQ002', '注塑机2号', 1, '正常', '生产车间A区', '2020-03-20', '海天注塑机', '2023-12-15', '2024-03-15', '800吨注塑机'),
('EQ003', '冲压机1号', 2, '正常', '生产车间B区', '2019-11-10', '徐锻压机', '2023-11-20', '2024-02-20', '200吨冲床'),
('EQ004', '数控铣床1号', 4, '维修', '模具车间', '2021-05-08', '牧野机床', '2023-10-10', '2024-01-10', '高精度数控铣床'),
('EQ005', '电火花机床1号', 5, '正常', '模具车间', '2021-08-15', '沙迪克', '2023-12-05', '2024-03-05', '精密电火花加工机床');

-- 插入模具数据
INSERT INTO `mold` (`mold_code`, `mold_name`, `mold_type_id`, `mold_status_id`, `specification`, `material`, `life_cycle`, `current_count`, `manufacture_date`, `manufacturer`, `description`) VALUES
('MD001', '手机外壳模具', 1, 1, '150x80x20mm', 'SKD61', 100000, 12500, '2022-01-15', '精密模具厂', '用于生产智能手机外壳'),
('MD002', '键盘按键模具', 1, 1, '30x30x15mm', 'P20', 200000, 35000, '2022-03-20', '精密模具厂', '用于生产电脑键盘按键'),
('MD003', '汽车配件模具', 3, 4, '200x150x50mm', 'H13', 80000, 0, '2022-05-10', '汽车模具厂', '用于生产汽车内饰配件'),
('MD004', '电子元件模具', 1, 2, '50x50x10mm', '718H', 150000, 89000, '2022-07-05', '精密模具厂', '用于生产电子连接器'),
('MD005', '金属冲压模具', 2, 3, '100x80x30mm', 'Cr12MoV', 120000, 78000, '2022-09-15', '五金模具厂', '用于金属零件冲压成型');

-- 插入系统参数数据
INSERT INTO `system_parameter` (`param_key`, `param_value`, `param_type`, `description`, `is_visible`) VALUES
('SYSTEM_NAME', '模具数字化管理系统', 'STRING', '系统名称', 1),
('SYSTEM_VERSION', 'V1.0.0', 'STRING', '系统版本号', 1),
('MAX_LOGIN_ATTEMPTS', '5', 'NUMBER', '最大登录尝试次数', 0),
('PASSWORD_EXPIRE_DAYS', '90', 'NUMBER', '密码过期天数', 0),
('MOLD_WARNING_USAGE_RATE', '80', 'NUMBER', '模具使用次数预警比例(%)', 1),
('DEFAULT_PAGE_SIZE', '10', 'NUMBER', '默认分页大小', 1),
('MAX_PAGE_SIZE', '100', 'NUMBER', '最大分页大小', 1);

-- 插入生产任务数据（模拟数据）
INSERT INTO `production_task` (`task_code`, `task_name`, `mold_id`, `equipment_id`, `operator_id`, `planned_quantity`, `actual_quantity`, `qualified_quantity`, `defective_quantity`, `status`, `start_time`, `end_time`, `description`) VALUES
('PT001', '手机外壳生产任务', 1, 1, 5, 5000, 4800, 4700, 100, '已完成', '2024-01-10 08:00:00', '2024-01-10 18:00:00', '生产智能手机外壳'),
('PT002', '键盘按键生产任务', 2, 2, 5, 10000, 9500, 9400, 100, '已完成', '2024-01-11 08:00:00', '2024-01-11 20:00:00', '生产电脑键盘按键'),
('PT003', '电子元件生产任务', 4, 1, 5, 3000, 0, 0, 0, '待开始', NULL, NULL, '生产电子连接器'),
('PT004', '金属零件冲压任务', 5, 3, 5, 2000, 0, 0, 0, '待开始', NULL, NULL, '金属零件冲压成型');

-- 插入生产记录数据（模拟数据）
INSERT INTO `production_record` (`task_id`, `mold_id`, `equipment_id`, `operator_id`, `production_date`, `production_quantity`, `qualified_quantity`, `defective_quantity`, `mold_usage_count`, `equipment_parameters`, `remark`) VALUES
(1, 1, 1, 5, '2024-01-10 08:00:00', 1000, 980, 20, 200, '{"temperature": 220, "pressure": 120, "speed": 50}', '上午批次'),
(1, 1, 1, 5, '2024-01-10 13:00:00', 1200, 1180, 20, 240, '{"temperature": 225, "pressure": 125, "speed": 52}', '下午批次1'),
(1, 1, 1, 5, '2024-01-10 16:00:00', 1000, 985, 15, 200, '{"temperature": 222, "pressure": 122, "speed": 51}', '下午批次2'),
(2, 2, 2, 5, '2024-01-11 08:00:00', 2000, 1980, 20, 300, '{"temperature": 210, "pressure": 110, "speed": 48}', '上午批次'),
(2, 2, 2, 5, '2024-01-11 13:00:00', 2200, 2180, 20, 330, '{"temperature": 215, "pressure": 115, "speed": 50}', '下午批次1'),
(2, 2, 2, 5, '2024-01-11 17:00:00', 1800, 1780, 20, 270, '{"temperature": 212, "pressure": 112, "speed": 49}', '下午批次2');