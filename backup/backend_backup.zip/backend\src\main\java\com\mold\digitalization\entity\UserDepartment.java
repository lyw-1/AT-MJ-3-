package com.mold.digitalization.entity;

import lombok.Data;

@Data
public class UserDepartment {
    private Long userId;
    private Long departmentId;
}

