package com.mold.digitalization.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mold.digitalization.entity.ProcessPreset;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

/**
 * 工序预设置Mapper
 */
@Mapper
public interface ProcessPresetMapper extends BaseMapper<ProcessPreset> {
    
    /**
     * 根据模具ID和工序代码查询预设置列表
     * @param moldId 模具ID
     * @param processCode 工序代码
     * @return 预设置列表
     */
    List<ProcessPreset> getByMoldIdAndProcessCode(Long moldId, String processCode);
    
    /**
     * 根据模具ID查询所有预设置
     * @param moldId 模具ID
     * @return 预设置列表
     */
    List<ProcessPreset> getByMoldId(Long moldId);
    
    /**
     * 根据工序代码查询所有预设置
     * @param processCode 工序代码
     * @return 预设置列表
     */
    List<ProcessPreset> getByProcessCode(String processCode);
    
    /**
     * 根据模具ID和工序代码删除预设置
     * @param moldId 模具ID
     * @param processCode 工序代码
     * @return 删除数量
     */
    int deleteByMoldIdAndProcessCode(Long moldId, String processCode);
    
    /**
     * 根据模具ID删除所有预设置
     * @param moldId 模具ID
     * @return 删除数量
     */
    int deleteByMoldId(Long moldId);
}
