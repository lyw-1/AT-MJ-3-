package com.mold.digitalization.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mold.digitalization.entity.EquipmentMaintenanceCycle;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface EquipmentMaintenanceCycleMapper extends BaseMapper<EquipmentMaintenanceCycle> {
}

