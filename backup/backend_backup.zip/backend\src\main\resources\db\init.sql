CREATE TABLE IF NOT EXISTS `product_spec` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `spec_code` VARCHAR(50) NULL,
  `spec_name` VARCHAR(100) NOT NULL,
  `description` VARCHAR(500) NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `product` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `product_code` VARCHAR(50) NOT NULL,
  `product_name` VARCHAR(100) NOT NULL,
  `spec_id` BIGINT NULL,
  `status` INT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_code` (`product_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `non_mold_application` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(100) NOT NULL,
  `description` VARCHAR(500) NULL,
  `applicant_user_id` BIGINT NOT NULL,
  `status` INT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `mold` ADD COLUMN IF NOT EXISTS `is_key` TINYINT(1) DEFAULT 0;

-- 工序预设置表
CREATE TABLE IF NOT EXISTS `process_preset` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `mold_id` BIGINT NOT NULL,
  `process_code` VARCHAR(50) NOT NULL,
  `preset_key` VARCHAR(100) NOT NULL,
  `preset_value` TEXT NULL,
  `description` VARCHAR(500) NULL,
  `create_time` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mold_id` (`mold_id`),
  KEY `idx_process_code` (`process_code`),
  KEY `idx_mold_process` (`mold_id`,`process_code`),
  KEY `idx_preset_key` (`preset_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
