-- 模具数字化管理系统数据库初始化脚本
-- 创建时间: 2023-07-01
-- 版本: 1.0

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS `mold_digitalization` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE `mold_digitalization`;

-- 1. 创建用户相关表

-- 创建用户表
CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `real_name` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号码',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `department` varchar(100) DEFAULT NULL COMMENT '所属部门',
  `position` varchar(100) DEFAULT NULL COMMENT '职位',
  `status` tinyint(4) DEFAULT 1 COMMENT '状态：1启用，0禁用',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 创建角色表
CREATE TABLE IF NOT EXISTS `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(50) NOT NULL COMMENT '角色名称',
  `description` varchar(200) DEFAULT NULL COMMENT '角色描述',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

-- 创建权限表
CREATE TABLE IF NOT EXISTS `permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '权限ID',
  `permission_name` varchar(100) NOT NULL COMMENT '权限名称',
  `permission_code` varchar(100) NOT NULL COMMENT '权限代码',
  `description` varchar(200) DEFAULT NULL COMMENT '权限描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permission_code` (`permission_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='权限表';

-- 创建用户角色关联表
CREATE TABLE IF NOT EXISTS `user_role` (
  `user_id` bigint(20) NOT NULL COMMENT '用户ID',
  `role_id` bigint(20) NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `idx_role_id` (`role_id`),
  CONSTRAINT `fk_user_role_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_role_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色关联表';

-- 2. 创建模具相关基础表

-- 创建模具类型表
CREATE TABLE IF NOT EXISTS `mold_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '类型ID',
  `type_name` varchar(100) NOT NULL COMMENT '类型名称',
  `description` varchar(200) DEFAULT NULL COMMENT '类型描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_type_name` (`type_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模具类型表';

-- 创建模具状态表
CREATE TABLE IF NOT EXISTS `mold_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '状态ID',
  `status_code` varchar(50) NOT NULL COMMENT '状态编码',
  `status_name` varchar(100) NOT NULL COMMENT '状态名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_status_code` (`status_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模具状态表';

-- 3. 创建模具主表
CREATE TABLE IF NOT EXISTS `mold` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '模具ID',
  `mold_code` varchar(100) NOT NULL COMMENT '模具编号',
  `mold_name` varchar(200) NOT NULL COMMENT '模具名称',
  `mold_type_id` bigint(20) NOT NULL COMMENT '模具类型ID',
  `mold_status_id` bigint(20) NOT NULL COMMENT '模具状态ID',
  `description` varchar(500) DEFAULT NULL COMMENT '模具描述',
  `material` varchar(100) DEFAULT NULL COMMENT '材料',
  `version` varchar(50) DEFAULT NULL COMMENT '版本号',
  `designer` varchar(100) DEFAULT NULL COMMENT '设计人',
  `creation_date` date DEFAULT NULL COMMENT '创建日期',
  `length` decimal(10,2) DEFAULT NULL COMMENT '长度(mm)',
  `width` decimal(10,2) DEFAULT NULL COMMENT '宽度(mm)',
  `height` decimal(10,2) DEFAULT NULL COMMENT '高度(mm)',
  `weight` decimal(10,2) DEFAULT NULL COMMENT '重量(kg)',
  `storage_location` varchar(200) DEFAULT NULL COMMENT '存放位置',
  `last_maintenance_date` date DEFAULT NULL COMMENT '最后维护日期',
  `maintenance_cycle` int(11) DEFAULT NULL COMMENT '维护周期(天)',
  `is_active` tinyint(4) DEFAULT 1 COMMENT '是否启用：1启用，0禁用',
  `responsible_user_id` bigint(20) DEFAULT NULL COMMENT '负责人ID',
  `creator_id` bigint(20) DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mold_code` (`mold_code`),
  KEY `idx_mold_type_id` (`mold_type_id`),
  KEY `idx_mold_status_id` (`mold_status_id`),
  KEY `idx_responsible_user_id` (`responsible_user_id`),
  KEY `idx_storage_location` (`storage_location`),
  CONSTRAINT `fk_mold_type` FOREIGN KEY (`mold_type_id`) REFERENCES `mold_type` (`id`),
  CONSTRAINT `fk_mold_status` FOREIGN KEY (`mold_status_id`) REFERENCES `mold_status` (`id`),
  CONSTRAINT `fk_mold_responsible_user` FOREIGN KEY (`responsible_user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_mold_creator` FOREIGN KEY (`creator_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模具主表';

-- 4. 创建配件相关表

-- 创建配件类型表
CREATE TABLE IF NOT EXISTS `accessory_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '类型ID',
  `type_name` varchar(100) NOT NULL COMMENT '类型名称',
  `description` varchar(200) DEFAULT NULL COMMENT '类型描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_accessory_type_name` (`type_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='配件类型表';

-- 创建配件主表
CREATE TABLE IF NOT EXISTS `accessory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '配件ID',
  `accessory_code` varchar(100) NOT NULL COMMENT '配件编号',
  `accessory_name` varchar(200) NOT NULL COMMENT '配件名称',
  `accessory_type_id` bigint(20) NOT NULL COMMENT '配件类型ID',
  `specification` varchar(200) DEFAULT NULL COMMENT '规格',
  `material` varchar(100) DEFAULT NULL COMMENT '材料',
  `unit` varchar(50) DEFAULT NULL COMMENT '单位',
  `stock_quantity` int(11) DEFAULT 0 COMMENT '库存数量',
  `minimum_stock` int(11) DEFAULT 0 COMMENT '最小库存量',
  `storage_location` varchar(200) DEFAULT NULL COMMENT '存放位置',
  `supplier` varchar(200) DEFAULT NULL COMMENT '供应商',
  `unit_price` decimal(10,2) DEFAULT 0 COMMENT '单价',
  `status` tinyint(4) DEFAULT 1 COMMENT '状态：1正常，0停用',
  `creator_id` bigint(20) DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_accessory_code` (`accessory_code`),
  KEY `idx_accessory_type_id` (`accessory_type_id`),
  KEY `idx_storage_location` (`storage_location`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_accessory_type` FOREIGN KEY (`accessory_type_id`) REFERENCES `accessory_type` (`id`),
  CONSTRAINT `fk_accessory_creator` FOREIGN KEY (`creator_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='配件主表';

-- 5. 创建模具入库记录表
CREATE TABLE IF NOT EXISTS `mold_storage_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `mold_id` bigint(20) NOT NULL COMMENT '模具ID',
  `storage_date` datetime NOT NULL COMMENT '入库日期',
  `storage_operator_id` bigint(20) NOT NULL COMMENT '入库操作人ID',
  `storage_location` varchar(200) NOT NULL COMMENT '入库位置',
  `inspection_result` varchar(50) DEFAULT NULL COMMENT '检验结果',
  `inspection_note` varchar(500) DEFAULT NULL COMMENT '检验备注',
  `quantity` int(11) DEFAULT 1 COMMENT '数量',
  `is_approved` tinyint(4) DEFAULT 0 COMMENT '是否已审核',
  `approval_user_id` bigint(20) DEFAULT NULL COMMENT '审核人ID',
  `approval_time` datetime DEFAULT NULL COMMENT '审核时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_mold_id` (`mold_id`),
  KEY `idx_storage_operator_id` (`storage_operator_id`),
  KEY `idx_approval_user_id` (`approval_user_id`),
  KEY `idx_storage_date` (`storage_date`),
  CONSTRAINT `fk_storage_mold` FOREIGN KEY (`mold_id`) REFERENCES `mold` (`id`),
  CONSTRAINT `fk_storage_operator` FOREIGN KEY (`storage_operator_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_storage_approval_user` FOREIGN KEY (`approval_user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模具入库记录表';

-- 6. 创建模具借用归还记录表
CREATE TABLE IF NOT EXISTS `mold_borrow_return_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `mold_id` bigint(20) NOT NULL COMMENT '模具ID',
  `borrow_user_id` bigint(20) NOT NULL COMMENT '借用人ID',
  `borrow_date` datetime NOT NULL COMMENT '借用日期',
  `expected_return_date` datetime DEFAULT NULL COMMENT '预计归还日期',
  `actual_return_date` datetime DEFAULT NULL COMMENT '实际归还日期',
  `return_operator_id` bigint(20) DEFAULT NULL COMMENT '归还操作人ID',
  `borrow_purpose` varchar(500) DEFAULT NULL COMMENT '借用用途',
  `borrow_quantity` int(11) DEFAULT 1 COMMENT '借用数量',
  `return_quantity` int(11) DEFAULT 0 COMMENT '归还数量',
  `status` varchar(50) DEFAULT 'BORROWED' COMMENT '状态：BORROWED已借用，RETURNED已归还',
  `borrow_department` varchar(100) DEFAULT NULL COMMENT '借用部门',
  `inspection_result` varchar(50) DEFAULT NULL COMMENT '归还检验结果',
  `inspection_note` varchar(500) DEFAULT NULL COMMENT '归还检验备注',
  `is_overdue` tinyint(4) DEFAULT 0 COMMENT '是否逾期',
  `overdue_days` int(11) DEFAULT 0 COMMENT '逾期天数',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_mold_id` (`mold_id`),
  KEY `idx_borrow_user_id` (`borrow_user_id`),
  KEY `idx_return_operator_id` (`return_operator_id`),
  KEY `idx_borrow_date` (`borrow_date`),
  KEY `idx_actual_return_date` (`actual_return_date`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_borrow_return_mold` FOREIGN KEY (`mold_id`) REFERENCES `mold` (`id`),
  CONSTRAINT `fk_borrow_user` FOREIGN KEY (`borrow_user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fk_return_operator` FOREIGN KEY (`return_operator_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模具借用归还记录表';

-- 7. 创建配件检验记录表
CREATE TABLE IF NOT EXISTS `accessory_inspection_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录ID',
  `accessory_id` bigint(20) NOT NULL COMMENT '配件ID',
  `inspection_date` datetime NOT NULL COMMENT '检验日期',
  `inspector_id` bigint(20) NOT NULL COMMENT '检验员ID',
  `inspection_quantity` int(11) NOT NULL COMMENT '检验数量',
  `qualified_quantity` int(11) NOT NULL COMMENT '合格数量',
  `unqualified_quantity` int(11) NOT NULL COMMENT '不合格数量',
  `inspection_result` varchar(50) NOT NULL COMMENT '检验结果：合格、不合格、待处理',
  `defect_description` varchar(500) DEFAULT NULL COMMENT '缺陷描述',
  `processing_suggestion` varchar(500) DEFAULT NULL COMMENT '处理建议',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_accessory_id` (`accessory_id`),
  KEY `idx_inspector_id` (`inspector_id`),
  KEY `idx_inspection_date` (`inspection_date`),
  CONSTRAINT `fk_inspection_accessory` FOREIGN KEY (`accessory_id`) REFERENCES `accessory` (`id`),
  CONSTRAINT `fk_inspector_user` FOREIGN KEY (`inspector_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='配件检验记录表';

-- 插入初始数据

-- 插入模具类型
INSERT INTO `mold_type` (`type_name`, `description`) VALUES
('注塑模具', '用于塑料注塑成型'),
('压铸模具', '用于金属压铸成型'),
('冲压模具', '用于金属板材冲压'),
('锻造模具', '用于金属锻造'),
('橡胶模具', '用于橡胶制品成型');

-- 插入模具状态
INSERT INTO `mold_status` (`status_code`, `status_name`) VALUES
('IN_STORAGE', '在库'),
('IN_USE', '使用中'),
('MAINTENANCE', '维护中'),
('SCRAPPED', '报废'),
('REPAIRING', '维修中');

-- 插入配件类型
INSERT INTO `accessory_type` (`type_name`, `description`) VALUES
('标准件', '标准规格的通用配件'),
('易损件', '容易磨损需要经常更换的配件'),
('特殊件', '特定模具专用的特殊配件'),
('工具', '用于模具维护和操作的工具'),
('耗材', '模具生产过程中消耗的材料');

-- 创建数据库用户并授权
-- 注意：在实际环境中，请替换为强密码
CREATE USER IF NOT EXISTS 'mold_user'@'%' IDENTIFIED BY 'MoldDigital123!';
GRANT ALL PRIVILEGES ON `mold_digitalization`.* TO 'mold_user'@'%';
FLUSH PRIVILEGES;

SET FOREIGN_KEY_CHECKS = 1;

-- 脚本执行完成提示
SELECT '数据库初始化完成' AS result;
