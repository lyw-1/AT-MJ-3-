-- MySQL 索引重命名脚本（安全：仅当索引存在时执行）
-- 目标表：process_status_history

-- 重命名：idx_psh_process_id -> idx_process_id
SET @has_idx_psh_process_id = (
  SELECT COUNT(1) FROM information_schema.STATISTICS 
  WHERE table_schema = DATABASE() 
    AND table_name = 'process_status_history' 
    AND index_name = 'idx_psh_process_id'
);

SET @sql1 = IF(@has_idx_psh_process_id > 0,
  'ALTER TABLE process_status_history RENAME INDEX idx_psh_process_id TO idx_process_id;',
  'SELECT "skip rename idx_psh_process_id (not exists)";'
);
PREPARE stmt1 FROM @sql1; EXECUTE stmt1; DEALLOCATE PREPARE stmt1;

-- 重命名：idx_psh_transition_time -> idx_transition_time
SET @has_idx_psh_transition_time = (
  SELECT COUNT(1) FROM information_schema.STATISTICS 
  WHERE table_schema = DATABASE() 
    AND table_name = 'process_status_history' 
    AND index_name = 'idx_psh_transition_time'
);

SET @sql2 = IF(@has_idx_psh_transition_time > 0,
  'ALTER TABLE process_status_history RENAME INDEX idx_psh_transition_time TO idx_transition_time;',
  'SELECT "skip rename idx_psh_transition_time (not exists)";'
);
PREPARE stmt2 FROM @sql2; EXECUTE stmt2; DEALLOCATE PREPARE stmt2;

-- 可选：如需确保索引列覆盖正确，可追加检查列的语句（此处略）

