-- 模具数字化系统生产环境数据库初始化脚本
-- 创建数据库和所有表结构

-- 创建数据库
CREATE DATABASE IF NOT EXISTS mold_digitalization CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE mold_digitalization;

-- 用户表
CREATE TABLE IF NOT EXISTS `user` (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    real_name VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    status TINYINT NOT NULL DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
    remark VARCHAR(500),
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    login_failed_count INT DEFAULT 0 COMMENT '登录失败次数',
    locked_until DATETIME COMMENT '锁定截止时间',
    lock_reason VARCHAR(500) COMMENT '锁定原因',
    last_login_ip VARCHAR(50) COMMENT '最后登录IP',
    last_login_time DATETIME COMMENT '最后登录时间',
    CONSTRAINT uk_username UNIQUE (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 角色表
CREATE TABLE IF NOT EXISTS `role` (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL,
    description VARCHAR(200),
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uk_role_name UNIQUE (role_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

-- 用户角色关联表
CREATE TABLE IF NOT EXISTS `user_role` (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    role_id BIGINT NOT NULL,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_user_role UNIQUE (user_id, role_id),
    CONSTRAINT fk_user_role_user FOREIGN KEY (user_id) REFERENCES `user`(id) ON DELETE CASCADE,
    CONSTRAINT fk_user_role_role FOREIGN KEY (role_id) REFERENCES `role`(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色关联表';

-- 深孔钻工艺表
CREATE TABLE IF NOT EXISTS deep_hole_process (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  mold_id BIGINT,
  mold_code VARCHAR(50),
  equipment_id BIGINT,
  equipment_name VARCHAR(100),
  craft_type INT COMMENT '1-分层，2-预钻',
  status INT COMMENT '状态：0-未开始，1-进行中，2-已完成',
  planned_layer_count INT,
  expected_finish_time DATETIME,
  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 深孔钻分层记录表
CREATE TABLE IF NOT EXISTS deep_hole_layer_record (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  layer_index INT,
  depth DOUBLE,
  multi_speed_hf VARCHAR(100),
  single_hole_time_sec INT,
  through_hole_count INT,
  layer_time_sec INT,
  start_time DATETIME,
  end_time DATETIME,
  remark VARCHAR(200),
  CONSTRAINT fk_layer_process FOREIGN KEY (process_id) REFERENCES deep_hole_process(id)
);

-- 深孔钻预钻批次表
CREATE TABLE IF NOT EXISTS deep_hole_pre_drill_batch (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  hole_count INT,
  depth DOUBLE,
  single_hole_time_sec INT,
  batch_time_sec INT,
  start_time DATETIME,
  end_time DATETIME,
  CONSTRAINT fk_pre_drill_process FOREIGN KEY (process_id) REFERENCES deep_hole_process(id)
);

-- 切槽机工艺表
CREATE TABLE IF NOT EXISTS slotting_process (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  mold_id BIGINT,
  mold_code VARCHAR(50),
  equipment_id BIGINT,
  equipment_name VARCHAR(100),
  status INT COMMENT '状态：0-未开始，1-进行中，2-已完成',
  planned_slot_count INT,
  expected_finish_time DATETIME,
  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 切槽机记录表
CREATE TABLE IF NOT EXISTS slotting_record (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  slot_index INT,
  width DOUBLE,
  depth DOUBLE,
  slot_time_sec INT,
  start_time DATETIME,
  end_time DATETIME,
  remark VARCHAR(200),
  CONSTRAINT fk_slotting_record_process FOREIGN KEY (process_id) REFERENCES slotting_process(id)
);

-- EDM成型工艺表
CREATE TABLE IF NOT EXISTS edm_forming_process (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  mold_id BIGINT,
  mold_code VARCHAR(50),
  equipment_id BIGINT,
  equipment_name VARCHAR(100),
  status INT COMMENT '状态：0-未开始，1-进行中，2-已完成',
  electrode_type VARCHAR(100),
  planned_erosion_time_sec INT,
  expected_finish_time DATETIME,
  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- EDM成型记录表
CREATE TABLE IF NOT EXISTS edm_forming_record (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  erosion_time_sec INT,
  electrode_wear_mm DOUBLE,
  surface_roughness_ra DOUBLE,
  start_time DATETIME,
  end_time DATETIME,
  remark VARCHAR(200),
  CONSTRAINT fk_edm_forming_record_process FOREIGN KEY (process_id) REFERENCES edm_forming_process(id)
);

-- 雕刻工艺表
CREATE TABLE IF NOT EXISTS engraving_process (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  mold_id BIGINT,
  mold_code VARCHAR(50),
  equipment_id BIGINT,
  equipment_name VARCHAR(100),
  status INT COMMENT '状态：0-未开始，1-进行中，2-已完成',
  planned_engraving_time_sec INT,
  expected_finish_time DATETIME,
  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 雕刻记录表
CREATE TABLE IF NOT EXISTS engraving_record (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  engraving_time_sec INT,
  tool_diameter_mm DOUBLE,
  spindle_speed_rpm INT,
  feed_rate_mm_min DOUBLE,
  start_time DATETIME,
  end_time DATETIME,
  remark VARCHAR(200),
  CONSTRAINT fk_engraving_record_process FOREIGN KEY (process_id) REFERENCES engraving_process(id)
);

-- 线割工艺表
CREATE TABLE IF NOT EXISTS wire_cut_process (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  mold_id BIGINT,
  mold_code VARCHAR(50),
  equipment_id BIGINT,
  equipment_name VARCHAR(100),
  status INT COMMENT '状态：0-未开始，1-进行中，2-已完成',
  wire_diameter_mm DOUBLE,
  planned_cut_time_sec INT,
  expected_finish_time DATETIME,
  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 线割记录表
CREATE TABLE IF NOT EXISTS wire_cut_record (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  cut_time_sec INT,
  wire_speed_mm_min DOUBLE,
  surface_roughness_ra DOUBLE,
  start_time DATETIME,
  end_time DATETIME,
  remark VARCHAR(200),
  CONSTRAINT fk_wire_cut_record_process FOREIGN KEY (process_id) REFERENCES wire_cut_process(id)
);

-- 热处理工艺表
CREATE TABLE IF NOT EXISTS heat_treatment_process (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  mold_id BIGINT,
  mold_code VARCHAR(50),
  equipment_id BIGINT,
  equipment_name VARCHAR(100),
  status INT COMMENT '状态：0-未开始，1-进行中，2-已完成',
  treatment_type VARCHAR(100),
  temperature_celsius INT,
  duration_hours INT,
  expected_finish_time DATETIME,
  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 热处理记录表
CREATE TABLE IF NOT EXISTS heat_treatment_record (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  actual_temperature_celsius INT,
  actual_duration_hours INT,
  hardness_hrc DOUBLE,
  start_time DATETIME,
  end_time DATETIME,
  remark VARCHAR(200),
  CONSTRAINT fk_heat_treatment_record_process FOREIGN KEY (process_id) REFERENCES heat_treatment_process(id)
);

-- 裸模检验表
CREATE TABLE IF NOT EXISTS bare_mold_inspection (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  mold_id BIGINT,
  mold_code VARCHAR(50),
  equipment_id BIGINT,
  equipment_name VARCHAR(100),
  status INT COMMENT '状态：0-未开始，1-进行中，2-已完成',
  inspection_type VARCHAR(100),
  expected_finish_time DATETIME,
  create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
  update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 裸模检验记录表
CREATE TABLE IF NOT EXISTS bare_mold_inspection_record (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  process_id BIGINT,
  dimension_tolerance_mm DOUBLE,
  surface_quality_grade INT,
  defect_description VARCHAR(500),
  inspection_result VARCHAR(100),
  start_time DATETIME,
  end_time DATETIME,
  remark VARCHAR(200),
  CONSTRAINT fk_bare_mold_inspection_record_process FOREIGN KEY (process_id) REFERENCES bare_mold_inspection(id)
);

-- 创建索引
CREATE INDEX idx_dhp_mold_code ON deep_hole_process(mold_code);
CREATE INDEX idx_dhl_process ON deep_hole_layer_record(process_id);
CREATE INDEX idx_dhpdb_process ON deep_hole_pre_drill_batch(process_id);
CREATE INDEX idx_sp_mold_code ON slotting_process(mold_code);
CREATE INDEX idx_sr_process ON slotting_record(process_id);
CREATE INDEX idx_edm_mold_code ON edm_forming_process(mold_code);
CREATE INDEX idx_edm_record_process ON edm_forming_record(process_id);
CREATE INDEX idx_engraving_mold_code ON engraving_process(mold_code);
CREATE INDEX idx_engraving_record_process ON engraving_record(process_id);
CREATE INDEX idx_wire_cut_mold_code ON wire_cut_process(mold_code);
CREATE INDEX idx_wire_cut_record_process ON wire_cut_record(process_id);
CREATE INDEX idx_heat_treatment_mold_code ON heat_treatment_process(mold_code);
CREATE INDEX idx_heat_treatment_record_process ON heat_treatment_record(process_id);
CREATE INDEX idx_bare_mold_inspection_mold_code ON bare_mold_inspection(mold_code);
CREATE INDEX idx_bare_mold_inspection_record_process ON bare_mold_inspection_record(process_id);

-- 插入默认管理员用户（密码：admin123）
INSERT IGNORE INTO `user` (username, password, real_name, email, status) VALUES 
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBaUKk7h.T0mUO', '管理员', 'admin@your-domain.com', 1);

-- 插入默认角色
INSERT IGNORE INTO `role` (role_name, description) VALUES 
('ADMIN', '系统管理员'),
('USER', '普通用户'),
('OPERATOR', '操作员');

-- 给管理员分配ADMIN角色
INSERT IGNORE INTO `user_role` (user_id, role_id) 
SELECT u.id, r.id FROM `user` u, `role` r WHERE u.username = 'admin' AND r.role_name = 'ADMIN';