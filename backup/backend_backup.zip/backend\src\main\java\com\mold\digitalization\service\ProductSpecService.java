package com.mold.digitalization.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mold.digitalization.entity.ProductSpec;

public interface ProductSpecService extends IService<ProductSpec> {
}
