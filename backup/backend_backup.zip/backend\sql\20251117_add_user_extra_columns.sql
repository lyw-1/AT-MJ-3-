-- 新增用户扩展列：real_name、department_name、phone、email
-- 在 MySQL 8.0+ 环境支持 IF NOT EXISTS，重复执行不会出错

ALTER TABLE `user`
  ADD COLUMN IF NOT EXISTS `real_name` VARCHAR(50) NULL COMMENT '真实姓名' AFTER `password`;

ALTER TABLE `user`
  ADD COLUMN IF NOT EXISTS `department_name` VARCHAR(100) NULL COMMENT '部门名称' AFTER `real_name`;

ALTER TABLE `user`
  ADD COLUMN IF NOT EXISTS `phone` VARCHAR(20) NULL COMMENT '手机号' AFTER `department_name`;

ALTER TABLE `user`
  ADD COLUMN IF NOT EXISTS `email` VARCHAR(100) NULL COMMENT '邮箱' AFTER `phone`;

-- 可选：为常用查询字段添加索引（如需）
-- CREATE INDEX IF NOT EXISTS idx_user_username ON `user`(`username`);
-- CREATE INDEX IF NOT EXISTS idx_user_phone ON `user`(`phone`);
