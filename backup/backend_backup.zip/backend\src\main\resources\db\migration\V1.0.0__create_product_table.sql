-- 创建成品表
CREATE TABLE IF NOT EXISTS `product` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '成品ID',
  `product_category` VARCHAR(255) NULL COMMENT '成品类别',
  `product_spec` VARCHAR(255) NULL COMMENT '成品规格',
  `density_requirement_min` DOUBLE NULL COMMENT '容重要求最小值',
  `density_requirement_max` DOUBLE NULL COMMENT '容重要求最大值',
  `wall_thickness_requirement` DOUBLE NULL COMMENT '壁厚要求',
  `slot_width_requirement_min` DOUBLE NULL COMMENT '槽宽要求最小值',
  `slot_width_requirement_max` DOUBLE NULL COMMENT '槽宽要求最大值',
  `other_requirements` VARCHAR(500) NULL COMMENT '其他特殊要求',
  `create_time` VARCHAR(50) NULL COMMENT '创建时间',
  `update_time` VARCHAR(50) NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_product_category_spec` (`product_category`,`product_spec`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '成品表';

-- 插入初始成品数据
INSERT IGNORE INTO `product` (`product_category`, `product_spec`, `density_requirement_min`, `density_requirement_max`, `wall_thickness_requirement`, `slot_width_requirement_min`, `slot_width_requirement_max`, `other_requirements`, `create_time`, `update_time`) VALUES
('蜂窝陶瓷载体', 'Φ150×100', 0.8, 1.2, 0.15, 0.2, 0.25, '标准产品，用于汽车尾气处理', NOW(), NOW()),
('蜂窝陶瓷载体', 'Φ200×150', 0.9, 1.3, 0.18, 0.22, 0.28, '大尺寸产品，用于重型车辆', NOW(), NOW()),
('蜂窝陶瓷载体', 'Φ100×80', 0.7, 1.1, 0.12, 0.18, 0.23, '小尺寸产品，用于摩托车', NOW(), NOW()),
('催化剂载体', 'Φ120×90', 0.85, 1.25, 0.16, 0.21, 0.26, '高性能催化剂载体', NOW(), NOW()),
('过滤器载体', 'Φ180×120', 0.95, 1.35, 0.20, 0.24, 0.30, '用于工业废气处理', NOW(), NOW());