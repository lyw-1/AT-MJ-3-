-- PostgreSQL 索引重命名脚本
-- 目标表：process_status_history

DO $$
BEGIN
  -- idx_psh_process_id -> idx_process_id
  IF EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = ANY (current_schemas(false))
      AND tablename = 'process_status_history'
      AND indexname = 'idx_psh_process_id'
  ) THEN
    EXECUTE 'ALTER INDEX idx_psh_process_id RENAME TO idx_process_id';
  END IF;

  -- idx_psh_transition_time -> idx_transition_time
  IF EXISTS (
    SELECT 1 FROM pg_indexes 
    WHERE schemaname = ANY (current_schemas(false))
      AND tablename = 'process_status_history'
      AND indexname = 'idx_psh_transition_time'
  ) THEN
    EXECUTE 'ALTER INDEX idx_psh_transition_time RENAME TO idx_transition_time';
  END IF;
END $$;

