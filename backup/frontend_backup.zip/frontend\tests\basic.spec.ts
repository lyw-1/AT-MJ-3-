import { describe, it, expect } from 'vitest'

describe('smoke', () => {
  it('basic math works', () => {
    expect(1 + 1).toBe(2)
  })
})
