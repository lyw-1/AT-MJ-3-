<template>
  <RouterView />
</template>

<script setup lang="ts"></script>

<style>
/* 全局样式由 styles/theme.scss 提供 */
</style>
