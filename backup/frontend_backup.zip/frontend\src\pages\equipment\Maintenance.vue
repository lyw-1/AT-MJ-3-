<template><el-card class="canvas-card card-rounded-lg"><h2>保养记录</h2></el-card></template>
<script setup lang="ts"></script>
<style scoped>h2{margin:0}</style>
