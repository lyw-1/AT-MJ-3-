<template><div style="padding:24px">页面未找到</div></template>
<script setup lang="ts"></script>
