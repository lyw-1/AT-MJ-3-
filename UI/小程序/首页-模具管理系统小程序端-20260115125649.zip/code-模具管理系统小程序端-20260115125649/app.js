App({
  onLaunch() {},
  globalData: {}
})
