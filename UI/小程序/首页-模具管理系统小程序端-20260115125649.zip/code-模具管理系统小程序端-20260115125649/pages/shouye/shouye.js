Page({
  data: {},

  onShareAppMessage() {
    return {};
  },
});